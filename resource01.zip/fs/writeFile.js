const fs = require("fs");
const path = require('path');

// 覆盖操作
// fs.writeFileSync(path.join(__dirname, './1.txt'), "are you ok?");
// let data = fs.readFileSync(path.join(__dirname, './1.txt'), "utf8");

// console.log(data); // Hello world复制代码


// fs.writeFile("2.txt", "Hello world", err => {
//     if (!err) {
//         fs.readFile("2.txt", "utf8", (err, data) => {
//             console.log(data); // Hello world
//         });
//     }
// });

fs.appendFileSync(path.join(__dirname, './1.txt'), "append a dog");