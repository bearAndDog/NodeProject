const fs = require("fs");
const path = require('path');

// let buf = fs.readFileSync(path.join(__dirname, './1.txt'));
// let data = fs.readFileSync(path.join(__dirname, './1.txt'),'utf-8');

// console.log(buf); // <Buffer 48 65 6c 6c 6f>
// console.log(data); // Hello复制代码


// const fs = require("fs");



fs.readFile(path.join(__dirname, './1.txt'), "utf8", (err, data) => {
    // console.log(err); // null
    console.log(data); // Hello
});

console.log('====================')