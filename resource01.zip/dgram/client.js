const dgram = require('dgram');
const message = Buffer.from('一些字节');
const client = dgram.createSocket('udp4');


client.send('一些字节', 41234, 'localhost', (err) => {
    // 记得关掉
  client.close();
});