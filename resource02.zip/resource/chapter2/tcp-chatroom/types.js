module.exports = {
  login: 0,
  broadcast: 1,
  p2p: 2,
  log: 3
}
